#ifndef RTOS_2_CLASE_2_PARTE_2_INC_EXTRAS_H_
#define RTOS_2_CLASE_2_PARTE_2_INC_EXTRAS_H_

void post(tObjeto* objeto,char* mensaje);
void get(tObjeto* objeto,char* mensaje);
void imprimir(char* mensaje);

#endif /* RTOS_2_CLASE_2_PARTE_2_INC_EXTRAS_H_ */
